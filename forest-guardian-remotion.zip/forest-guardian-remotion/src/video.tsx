import React from 'react';
import {
  AbsoluteFill, Audio, OffthreadVideo, Sequence, interpolate,
  staticFile, useCurrentFrame
} from 'remotion';

// All four clips must be 1920x1080, 24 fps or a compatible source frame rate.
// Render uses real motion footage, NOT illustrations or placeholder CSS characters.
const shots = [
  {file:'clips/01-establishing.mp4', from:0, frames:72, zoomFrom:1.00, zoomTo:1.075},
  {file:'clips/02-reactor.mp4', from:72, frames:72, zoomFrom:1.02, zoomTo:1.11},
  {file:'clips/03-monster.mp4', from:144, frames:72, zoomFrom:1.00, zoomTo:1.07},
  {file:'clips/04-hero.mp4', from:216, frames:72, zoomFrom:1.02, zoomTo:1.18},
];

const Shot: React.FC<{file:string; frames:number; zoomFrom:number;zoomTo:number}> = ({file,frames,zoomFrom,zoomTo}) => {
  const frame = useCurrentFrame();
  const zoom = interpolate(frame,[0,frames-1],[zoomFrom,zoomTo],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  const opacity = Math.min(1, frame / 4, (frames-frame)/4);
  return (
    <AbsoluteFill style={{overflow:'hidden',backgroundColor:'#03090a',opacity}}>
      <AbsoluteFill style={{transform:`scale(${zoom})`, transformOrigin:'center center'}}>
        <OffthreadVideo src={staticFile(file)} muted style={{width:'100%',height:'100%',objectFit:'cover'}} />
      </AbsoluteFill>
      <AbsoluteFill style={{pointerEvents:'none',background:'linear-gradient(180deg, rgba(4,7,15,.12) 0%, rgba(4,7,15,0) 48%, rgba(0,4,9,.36) 100%)'}} />
    </AbsoluteFill>
  );
};

const ReactorPulse: React.FC = () => {
  const frame=useCurrentFrame();
  const a=interpolate(frame,[0,18,36,54,72],[0,.10,.02,.14,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <AbsoluteFill style={{backgroundColor:'#a837fc', opacity:a, mixBlendMode:'screen',pointerEvents:'none'}}/>;
};

export const ForestGuardian: React.FC = () => (
  <AbsoluteFill style={{backgroundColor:'#020408'}}>
    {shots.map((s,i)=>(
      <Sequence key={s.file} from={s.from} durationInFrames={s.frames} name={`Shot ${i+1}`}>
        <Shot file={s.file} frames={s.frames} zoomFrom={s.zoomFrom} zoomTo={s.zoomTo}/>
        {i===1 && <ReactorPulse/>}
      </Sequence>
    ))}
    {/* Optional: uncomment after placing a licensed score in public/audio/score.mp3 */}
    {/* <Audio src={staticFile('audio/score.mp3')} volume={0.65} /> */}
  </AbsoluteFill>
);
