import React from 'react';
import {Composition} from 'remotion';
import {ForestGuardian} from './video';

export const Root: React.FC = () => (
  <Composition
    id="ForestGuardian"
    component={ForestGuardian}
    durationInFrames={288}
    fps={24}
    width={1920}
    height={1080}
  />
);
