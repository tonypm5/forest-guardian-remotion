# Forest Guardian — Remotion finishing project

A *postproduction* pipeline for realistic Seedance source footage. Remotion does not create photorealistic battles out of CSS or JSX. This repository is intentionally designed to require high-quality **video clips**.

## Usage in Codex cloud

1. Extract/upload this project into a **new** repository (do not modify `nexsweet-updates`).
2. Generate/download four 3-second clips following `docs/SHOTLIST.md`.
3. Put clips in `public/clips/` named exactly:
   - `01-establishing.mp4`
   - `02-reactor.mp4`
   - `03-monster.mp4`
   - `04-hero.mp4`
4. In a terminal where package downloads are available, run:

```bash
npm install
npm run compositions
npm run render
```

Output: `out/forest-guardian.mp4`.

## Preconditions
Node.js >= 20 recommended, Chromium/Remotion browser dependencies available, and authorized package downloads. Video generation source clips are NOT bundled. Without four real videos, rendering is intentionally blocked rather than silently substituting crude shapes.

## Prompt for Codex

> Open this `forest-guardian-remotion` project. Use `/remotion-best-practices` to validate it. Confirm Node/Chromium are ready. Verify the four videos under `public/clips/`. If missing, list required assets from `docs/SHOTLIST.md` and do not synthesize cartoon placeholders. Once clips are present, run `npm install`, `npm run compositions`, and `npm run render`. Inspect a few frames and return `out/forest-guardian.mp4` as a downloadable artifact. Leave other repositories untouched.

## Footage rights
Keep the user's reference video as a reference, not as output or bundled assets unless expressly authorized. Do not expose private video files via public GitHub.
