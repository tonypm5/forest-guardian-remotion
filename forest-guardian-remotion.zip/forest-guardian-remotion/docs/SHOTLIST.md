# FOREST GUARDIAN — Reference-grade production brief

Deliverable: 12 seconds, UHD-capable 1920×1080 delivery, 24 fps, 16:9. Cinematic fantasy-mech realism, not motion graphics.

## Character continuity (required in each generation)
Same adult woman; waist-length deep emerald-green hair with loose wind-driven strands; engraved brass / gunmetal steampunk armor, exposed gears and pistons; glowing violet reactor in CENTER of chest (NOT orange). Right forearm contains a heavy gauntlet-mounted energy cannon. Face and armor identical in all shots. Forest: ancient cedars and firs, damp moss, volumetric fog, overcast light. Monster: single gigantic ancient stone-and-root creature, partly obscured by fog, with bioluminescent fissures. No text, no watermarks, no extra limbs, no armor redesigns.

## Source clips — generate as 4 separate 3-second MP4s

### 01-establishing.mp4 (00:00–00:03)
Very wide low-angle forest establishment, hero left foreground, immense silhouette far center between massive tree trunks, damp forest floor. Slow smooth dolly-in. Fog curls across ground. Physically plausible hair and foliage motion, realistic cinematography, coherent anatomy.

### 02-reactor.mp4 (00:03–00:06)
Medium low angle, same hero and attire, violet reactor pulses through brass framing, light reflecting on wet metal; subtle servo-actuated piston motion and breath. Camera pushes closer. Keep face/armor identical, purple light ONLY emanates from chest reactor.

### 03-monster.mp4 (00:06–00:09)
Over-the-shoulder view from right behind same hero; enormous stone-and-root creature moves forward out of fog. Hero raises RIGHT forearm cannon to aim. Atmospherically thick mist, true sense of scale and parallax, realistic mechanical articulation, strong anticipatory tension.

### 04-hero.mp4 (00:09–00:12)
Dramatic 3/4 frontal closeup of same woman aiming gauntlet mounted cannon off-frame at monster. Face resolute, long green hair caught in blast of wind. Violet energy builds inside reactor and weapon, light blooms on cheeks and bronze armor. Smooth forward dolly, not a jump cut. End right before firing, without text.

## Shared negative prompt
Cartoon, anime, illustration, poster, slideshow, frozen image, cutout, 2D animation, cheap CGI, floating disconnected parts, geometry morphing, distorted hands, extra fingers, extra limbs, creature scale changing, face switching, green eyes replacing green hair, orange chest core, overexposed highlights, inconsistent props, lettering, watermark.

## Seedance / Higgsfield workflow
Generate four source shots; use the SAME reference frame/character identity in all shots. Make end-frame of shot N visually similar to start-frame of shot N+1. Export with sound off if score is added in post. Download clips, name as specified, add to public/clips/.

## Quality gate before edit
Verify identical facial structure, hairstyle, chest reactor location/color, gauntlet side, monster identity, lens and environment continuity. Regenerate any clip that fails, rather than attempting to fix identity drift in Remotion.
